package pers.utils.urlUtils;

public class Params {
    String key;
    String value;

    public Params(String key, String value) {
        this.key = key;
        this.value = value;
    }
}
